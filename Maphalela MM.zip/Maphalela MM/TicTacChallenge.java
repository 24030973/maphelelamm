/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tictacchallenge;

/**
 *
 * @author OSCAR
 */

 import java.util.Scanner;

public class TicTacChallenge{

    public char[][] gameBoard;
    public char currentSymbol;
    

    public TicTacChallenge()
    {
        
        gameBoard = new char[3][3];
        currentSymbol = 'X';
        resetBoard();
        
        
        }

    public void resetBoard(){
        
        for (int i = 0; i < 3; i++){
            
            for (int j = 0; j < 3; j++){
                
                gameBoard[i][j] = '-';
                
            }
        }
        
        }

    public void showBoard(){
        
        System.out.println("-------------");
        
        for (int i = 0; i < 3; i++){
            
            System.out.print("| ");
            for (int j = 0; j < 3; j++){
                
                System.out.print(gameBoard[i][j] + " | ");
                
                
            }
            
            
            System.out.println();
            System.out.println("-------------");
        }
        
    }

    public void initiateGame(){
        
        
        boolean win = false;
        boolean draw = false;

        while (!win && !draw){
            
            
            showBoard();
            makeMove();
            
            win = findWinner();
            
            if (!win){
                
                
                draw = findDraw();
                
                if (!draw) {
                    
                    togglePlayer();
                    
                }
            }
            
        }

        showBoard();
        
        if (win){
            
            System.out.println("Congrats! Player " + currentSymbol + " wins!");
            
        } 
        
        else if (draw){
            
            System.out.println("It's a DRAW.");
            
        }
    }

    public void makeMove(){
        
        Scanner scan = new Scanner(System.in);
        int r, c;

        while(true){
            
            System.out.println("Player " + currentSymbol + ", make your move (row [1-3] and column [1-3]): ");
            r = scan.nextInt() - 1;
            c = scan.nextInt() - 1;

            if(r >= 0 && c >= 0 && r < 3 && c < 3 && gameBoard[r][c] == '-'){
                gameBoard[r][c] = currentSymbol;
                break;
            } else {
                System.out.println("Invalid move, try again.");
            }
        }
    }

    public boolean findWinner() {
        
        
        for (int i = 0; i < 3; i++) {
            if ((gameBoard[i][0] == currentSymbol && gameBoard[i][1] == currentSymbol && gameBoard[i][2] == currentSymbol) ||
                (gameBoard[0][i] == currentSymbol && gameBoard[1][i] == currentSymbol && gameBoard[2][i] == currentSymbol)) {
                return true;
            }
        }

        if ((gameBoard[0][0] == currentSymbol && gameBoard[1][1] == currentSymbol && gameBoard[2][2] == currentSymbol) ||
            (gameBoard[0][2] == currentSymbol && gameBoard[1][1] == currentSymbol && gameBoard[2][0] == currentSymbol)) {
            return true;
          }

        return false;
        
    }
    
    

    public boolean findDraw() {
        
        for (int i = 0; i < 3; i++) {
            
            
            for (int j = 0; j < 3; j++) {
                
                
                if (gameBoard[i][j] == '-') {
                    return false;
                }
                
              }
        }
        
        return true;
        
        
    }

    public void togglePlayer(){
        
        
        if (currentSymbol == 'X') {
            
            currentSymbol = 'O';
            
           }
        
        
        else {
            
            
            currentSymbol = 'X';
            
        }
    }

    public static void main(String[]args){
        
        
        TicTacChallenge challenge = new TicTacChallenge();
        
        challenge.initiateGame();
        
    }
    
    
    
    
      }
